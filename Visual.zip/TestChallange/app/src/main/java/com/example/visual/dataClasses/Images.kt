package com.example.visual.dataClasses

data class Images(var url: String)