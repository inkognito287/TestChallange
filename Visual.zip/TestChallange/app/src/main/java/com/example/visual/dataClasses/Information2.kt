package com.example.visual.dataClasses

class Information2(var title: Array<String>,var text: Array<String?>,var image: Array<Int>,var visibility: Array<Int>) {
}