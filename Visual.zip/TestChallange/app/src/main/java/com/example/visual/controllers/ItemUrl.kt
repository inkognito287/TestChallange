package com.example.visual.controllers

class ItemUrl(private var url: String) {

    fun getUrl(): String {
        return url
    }
    fun setUrl(url: String) {
        this.url = url
    }
}