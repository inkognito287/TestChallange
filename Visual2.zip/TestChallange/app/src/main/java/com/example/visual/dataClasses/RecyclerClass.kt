package com.example.visual.dataClasses

data class RecyclerClass(val imageId: Int, var title: String)