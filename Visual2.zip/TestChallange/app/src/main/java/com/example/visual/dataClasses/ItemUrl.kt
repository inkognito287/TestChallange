package com.example.visual.dataClasses

class ItemUrl(private var url: String) {

    fun getUrl(): String {
        return url
    }
    fun setUrl(url: String) {
        this.url = url
    }
}