package com.example.visual.dataClasses

class Information(var imgId: Array<Int>, var title: Array<String>)