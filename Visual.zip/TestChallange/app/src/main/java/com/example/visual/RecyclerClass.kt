package com.example.visual

data class RecyclerClass(val imageId: Int, var title: String)